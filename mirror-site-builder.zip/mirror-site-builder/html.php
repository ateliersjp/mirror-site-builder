<?php
return Closure::fromCallable(function ($content) {
	return $content;
});
?>